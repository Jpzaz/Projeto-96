package com.example.feedpage.domain.util

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class PostType(val status: String): Parcelable
